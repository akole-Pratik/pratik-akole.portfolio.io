// ==========================================================
// Pratik Akole — Portfolio v2 — private admin panel
// Talks directly to the GitHub Contents API. No server, no
// database — your GitHub repo IS the database. Only someone
// with a valid write-access token for this repo can save
// anything; everyone else only ever sees index.html (read-only).
// ==========================================================

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const state = {
  owner: '', repo: '', branch: 'main', token: '',
  sha: null, content: null, demoMode: false,
};

const CONTENT_PATH = 'data/content.json';
const UPLOAD_FOLDER = 'assets/uploads';

async function loadContentPublic() {
  const res = await fetch(CONTENT_PATH, { cache: 'no-store' });
  if (!res.ok) throw new Error('Could not load content.json for demo mode.');
  return res.json();
}

function escapeHtml(s) { return (s || '').toString().replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

function b64EncodeUnicode(str) {
  return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (m, p1) => String.fromCharCode('0x' + p1)));
}
function b64DecodeUnicode(str) {
  return decodeURIComponent(atob(str).split('').map(c => '%' + c.charCodeAt(0).toString(16).padStart(2, '0')).join(''));
}

async function ghApi(path, opts = {}) {
  const res = await fetch(`https://api.github.com/repos/${state.owner}/${state.repo}${path}`, {
    ...opts,
    headers: {
      'Authorization': `token ${state.token}`,
      'Accept': 'application/vnd.github+json',
      ...(opts.headers || {}),
    },
  });
  return res;
}

// ---------- Connection ----------
async function loadContentFromRepo() {
  const res = await ghApi(`/contents/${CONTENT_PATH}?ref=${state.branch}`);
  if (!res.ok) throw new Error(`Could not read ${CONTENT_PATH} (${res.status}). Check owner/repo/branch and that your token has Contents: Read & write on this repo.`);
  const json = await res.json();
  state.sha = json.sha;
  state.content = JSON.parse(b64DecodeUnicode(json.content));
}

async function saveContentToRepo() {
  const body = {
    message: `Update content.json via admin panel — ${new Date().toISOString()}`,
    content: b64EncodeUnicode(JSON.stringify(state.content, null, 2)),
    sha: state.sha,
    branch: state.branch,
  };
  const res = await ghApi(`/contents/${CONTENT_PATH}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `Save failed (${res.status})`);
  }
  const json = await res.json();
  state.sha = json.content.sha;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function uploadFile(file) {
  const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]/g, '_');
  const path = `${UPLOAD_FOLDER}/${Date.now()}-${safeName}`;
  const base64 = await fileToBase64(file);
  const res = await ghApi(`/contents/${path}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: `Upload ${safeName} via admin panel`, content: base64, branch: state.branch }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `Upload failed (${res.status})`);
  }
  return path; // relative path, works as a src on the Pages site
}

// ---------- Generic repeatable list editor ----------
function renderRepeatable(spec) {
  const container = $('#' + spec.containerId);
  container.innerHTML = '';
  spec.items.forEach((item, i) => {
    const card = document.createElement('div');
    card.className = 'admin-repeat-item';
    let html = `<div class="admin-repeat-item-title">${escapeHtml(spec.itemTitle(item, i))}</div><button type="button" class="remove-btn">✕ remove</button>`;
    spec.fields.forEach(f => {
      if (f.type === 'image') {
        const url = item[f.key] || '';
        html += `
          <div class="form-row">
            <label>${f.label}</label>
            <input type="text" data-field="${f.key}" data-type="text" value="${escapeHtml(url)}" placeholder="assets/uploads/your-image.png">
            <input type="file" accept="image/*" data-upload-target="${f.key}">
            ${url ? `<img class="admin-thumb-preview" data-preview="${f.key}" src="${url}" alt="">` : `<span></span>`}
          </div>`;
      } else if (f.type === 'filelist') {
        html += `
          <div class="form-row">
            <label>${f.label}</label>
            <input type="hidden" data-field="${f.key}" data-type="json" value='${escapeHtml(JSON.stringify(item[f.key] || []))}'>
            <div class="admin-file-list" data-filelist="${f.key}"></div>
            <input type="file" data-filelist-upload="${f.key}">
          </div>`;
      } else if (f.type === 'lines' || f.type === 'lines-pipe') {
        const v = f.type === 'lines-pipe'
          ? (item[f.key] || []).map(x => `${x.name} | ${x.level}`).join('\n')
          : (item[f.key] || []).join('\n');
        html += `<div class="form-row"><label>${f.label}</label><textarea data-field="${f.key}" data-type="${f.type}" rows="3">${escapeHtml(v)}</textarea></div>`;
      } else if (f.type === 'csv') {
        html += `<div class="form-row"><label>${f.label}</label><input type="text" data-field="${f.key}" data-type="csv" value="${escapeHtml((item[f.key] || []).join(', '))}"></div>`;
      } else if (f.type === 'textarea') {
        html += `<div class="form-row"><label>${f.label}</label><textarea data-field="${f.key}" data-type="text" rows="3">${escapeHtml(item[f.key] || '')}</textarea></div>`;
      } else if (f.type === 'checkbox') {
        html += `<label class="admin-checkbox-inline"><input type="checkbox" data-field="${f.key}" data-type="checkbox" ${item[f.key] ? 'checked' : ''}> ${f.label}</label>`;
      } else {
        html += `<div class="form-row"><label>${f.label}</label><input type="text" data-field="${f.key}" data-type="text" value="${escapeHtml(item[f.key] || '')}"></div>`;
      }
    });
    card.innerHTML = html;

    // remove
    card.querySelector('.remove-btn').addEventListener('click', () => {
      spec.items = collectRepeatable(spec);
      spec.items.splice(i, 1);
      renderRepeatable(spec);
    });

    // image upload wiring
    card.querySelectorAll('[data-upload-target]').forEach(inputFile => {
      inputFile.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const key = inputFile.dataset.uploadTarget;
        const textInput = card.querySelector(`[data-field="${key}"]`);
        try {
          textInput.value = 'Uploading…';
          const path = await uploadFile(file);
          textInput.value = path;
          const preview = card.querySelector(`[data-preview="${key}"]`);
          if (preview) preview.src = path;
        } catch (err) {
          alert('Upload failed: ' + err.message);
        }
      });
    });

    // filelist wiring
    card.querySelectorAll('[data-filelist-upload]').forEach(inputFile => {
      const key = inputFile.dataset.filelistUpload;
      const hidden = card.querySelector(`[data-field="${key}"]`);
      const listEl = card.querySelector(`[data-filelist="${key}"]`);
      const draw = () => {
        const files = JSON.parse(hidden.value || '[]');
        listEl.innerHTML = files.map((f, fi) => `<span class="admin-file-chip">📎 ${escapeHtml(f.name)} <button type="button" data-remove-file="${fi}">✕</button></span>`).join('');
        listEl.querySelectorAll('[data-remove-file]').forEach(btn => {
          btn.addEventListener('click', () => {
            const files2 = JSON.parse(hidden.value || '[]');
            files2.splice(Number(btn.dataset.removeFile), 1);
            hidden.value = JSON.stringify(files2);
            draw();
          });
        });
      };
      draw();
      inputFile.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        try {
          const path = await uploadFile(file);
          const files = JSON.parse(hidden.value || '[]');
          files.push({ name: file.name, url: path });
          hidden.value = JSON.stringify(files);
          draw();
          inputFile.value = '';
        } catch (err) {
          alert('Upload failed: ' + err.message);
        }
      });
    });

    container.appendChild(card);
  });
}

function collectRepeatable(spec) {
  const container = $('#' + spec.containerId);
  return $$('.admin-repeat-item', container).map(card => {
    const obj = {};
    spec.fields.forEach(f => {
      const input = card.querySelector(`[data-field="${f.key}"]`);
      if (!input) return;
      if (f.type === 'lines') obj[f.key] = input.value.split('\n').map(s => s.trim()).filter(Boolean);
      else if (f.type === 'lines-pipe') obj[f.key] = input.value.split('\n').map(s => s.trim()).filter(Boolean).map(line => {
        const [name, level] = line.split('|').map(s => (s || '').trim());
        return { name: name || '', level: level || 'Working' };
      });
      else if (f.type === 'csv') obj[f.key] = input.value.split(',').map(s => s.trim()).filter(Boolean);
      else if (f.type === 'checkbox') obj[f.key] = input.checked;
      else if (f.type === 'json') obj[f.key] = JSON.parse(input.value || '[]');
      else obj[f.key] = input.value;
    });
    return obj;
  });
}

function mountRepeatable(spec, addBtnId) {
  renderRepeatable(spec);
  $('#' + addBtnId).addEventListener('click', () => {
    spec.items = collectRepeatable(spec);
    spec.items.push(spec.newItem());
    renderRepeatable(spec);
  });
}

// ---------- Panel specs ----------
let statsSpec, factsSpec, expSpec, skillsSpec, certsSpec, achSpec, projSpec, stagesSpec;

function buildSpecs(content) {
  statsSpec = {
    containerId: 'h-stats', items: content.hero.stats,
    fields: [{ key: 'value', label: 'Value (e.g. 1.5+)' }, { key: 'label', label: 'Label (e.g. Yrs Experience)' }],
    itemTitle: (i, idx) => i.label || `Stat ${idx + 1}`,
    newItem: () => ({ value: '', label: '' }),
  };
  factsSpec = {
    containerId: 'a-facts', items: content.about.quickFacts,
    fields: [{ key: 'icon', label: 'Icon (emoji)' }, { key: 'label', label: 'Label' }, { key: 'value', label: 'Value' }],
    itemTitle: (i, idx) => i.label || `Fact ${idx + 1}`,
    newItem: () => ({ icon: '📌', label: '', value: '' }),
  };
  expSpec = {
    containerId: 'exp-list', items: content.experience,
    fields: [
      { key: 'company', label: 'Company' }, { key: 'role', label: 'Role' }, { key: 'period', label: 'Period (e.g. June 2023 – July 2024)' },
      { key: 'current', label: 'This is my current role', type: 'checkbox' },
      { key: 'points', label: 'Responsibilities — one per line', type: 'lines' },
    ],
    itemTitle: (i, idx) => i.company || `Role ${idx + 1}`,
    newItem: () => ({ id: 'exp-' + Date.now(), company: 'New company', role: '', period: '', current: false, points: [] }),
  };
  skillsSpec = {
    containerId: 'skills-list', items: content.skills,
    fields: [
      { key: 'category', label: 'Category name' }, { key: 'icon', label: 'Icon (emoji)' },
      { key: 'items', label: 'Skills — one per line, format: Skill name | Level  (Level: Core, Working, or Learning)', type: 'lines-pipe' },
    ],
    itemTitle: (i, idx) => i.category || `Category ${idx + 1}`,
    newItem: () => ({ category: 'New category', icon: '🔧', items: [] }),
  };
  certsSpec = {
    containerId: 'certs-list', items: content.certifications,
    fields: [{ key: 'icon', label: 'Icon (emoji)' }, { key: 'title', label: 'Title' }, { key: 'issuer', label: 'Issuer' }, { key: 'date', label: 'Date' }],
    itemTitle: (i, idx) => i.title || `Certification ${idx + 1}`,
    newItem: () => ({ icon: '🎓', title: '', issuer: '', date: '' }),
  };
  achSpec = {
    containerId: 'ach-list', items: content.achievements,
    fields: [{ key: 'icon', label: 'Icon (emoji)' }, { key: 'title', label: 'Title' }, { key: 'desc', label: 'Description' }, { key: 'date', label: 'Date' }],
    itemTitle: (i, idx) => i.title || `Achievement ${idx + 1}`,
    newItem: () => ({ icon: '🏆', title: '', desc: '', date: '' }),
  };
  projSpec = {
    containerId: 'proj-list', items: content.projects,
    fields: [
      { key: 'title', label: 'Project title' },
      { key: 'categories', label: 'Categories, comma separated (Power BI, SQL, Python, Excel, AI/ML)', type: 'csv' },
      { key: 'toolLine', label: 'Tool line (shown on the card)' },
      { key: 'summary', label: 'Short summary (shown on the card)', type: 'textarea' },
      { key: 'businessProblem', label: 'Business problem', type: 'textarea' },
      { key: 'dataset', label: 'Dataset', type: 'textarea' },
      { key: 'approach', label: 'Approach', type: 'textarea' },
      { key: 'tools', label: 'Tools used, comma separated', type: 'csv' },
      { key: 'kpis', label: 'KPIs — one per line', type: 'lines' },
      { key: 'businessQuestions', label: 'Business questions answered — one per line', type: 'lines' },
      { key: 'insights', label: 'Key insights — one per line', type: 'lines' },
      { key: 'impact', label: 'Business impact', type: 'textarea' },
      { key: 'dashboardImage', label: 'Dashboard preview image', type: 'image' },
      { key: 'dashboardLink', label: 'Live dashboard link (optional)' },
      { key: 'caseStudyLink', label: 'External case study link (optional)' },
      { key: 'files', label: 'Attached files — datasets, PDFs, extra screenshots', type: 'filelist' },
    ],
    itemTitle: (i, idx) => i.title || `Project ${idx + 1}`,
    newItem: () => ({ id: 'proj-' + Date.now(), title: 'New project', categories: [], toolLine: '', summary: '', businessProblem: '', dataset: '', approach: '', tools: [], kpis: [], businessQuestions: [], insights: [], impact: '', dashboardImage: '', dashboardLink: '', caseStudyLink: '', files: [] }),
  };
  stagesSpec = {
    containerId: 'ai-stages', items: content.aiAutomation.stages,
    fields: [{ key: 'title', label: 'Stage title' }, { key: 'desc', label: 'Description' }],
    itemTitle: (i, idx) => i.title || `Stage ${idx + 1}`,
    newItem: () => ({ title: '', desc: '' }),
  };
}

// ---------- Panel render/collect ----------
function renderPanels(content) {
  $('#h-name').value = content.hero.name;
  $('#h-shortName').value = content.hero.shortName;
  $('#h-status').value = content.hero.status;
  $('#h-taglineStart').value = content.hero.taglineStart;
  $('#h-taglineEnd').value = content.hero.taglineEnd;
  $('#h-bio').value = content.hero.bio;
  $('#h-linkedin').value = content.hero.linkedin;
  $('#h-github').value = content.hero.github;
  $('#h-resumeUrl').value = content.hero.resumeUrl;
  $('#h-resumeFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    $('#h-resumeUrl').value = 'Uploading…';
    try { $('#h-resumeUrl').value = await uploadFile(file); } catch (err) { alert('Upload failed: ' + err.message); }
  });

  $('#a-summary').value = content.about.summary;

  $('#ai-intro').value = content.aiAutomation.intro;
  $('#ai-tools').value = (content.aiAutomation.toolsLearning || []).join(', ');

  $('#c-email').value = content.contact.email;
  $('#c-phone').value = content.contact.phone;
  $('#c-location').value = content.contact.location;
  $('#c-whatsapp').value = content.contact.whatsapp || '';
  $('#c-linkedin').value = content.contact.linkedin;
  $('#c-github').value = content.contact.github;
  $('#c-formspree').value = content.contact.formspreeEndpoint || '';

  buildSpecs(content);
  mountRepeatable(statsSpec, 'h-stats-add');
  mountRepeatable(factsSpec, 'a-facts-add');
  mountRepeatable(expSpec, 'exp-add');
  mountRepeatable(skillsSpec, 'skills-add');
  mountRepeatable(certsSpec, 'certs-add');
  mountRepeatable(achSpec, 'ach-add');
  mountRepeatable(projSpec, 'proj-add');
  mountRepeatable(stagesSpec, 'ai-stages-add');
}

function collectAllIntoContent() {
  const content = state.content;
  content.hero.name = $('#h-name').value;
  content.hero.shortName = $('#h-shortName').value;
  content.hero.status = $('#h-status').value;
  content.hero.taglineStart = $('#h-taglineStart').value;
  content.hero.taglineEnd = $('#h-taglineEnd').value;
  content.hero.bio = $('#h-bio').value;
  content.hero.linkedin = $('#h-linkedin').value;
  content.hero.github = $('#h-github').value;
  content.hero.resumeUrl = $('#h-resumeUrl').value;
  content.hero.stats = collectRepeatable(statsSpec);

  content.about.summary = $('#a-summary').value;
  content.about.quickFacts = collectRepeatable(factsSpec);

  content.experience = collectRepeatable(expSpec);
  content.skills = collectRepeatable(skillsSpec);
  content.certifications = collectRepeatable(certsSpec);
  content.achievements = collectRepeatable(achSpec);
  content.projects = collectRepeatable(projSpec);

  content.aiAutomation.intro = $('#ai-intro').value;
  content.aiAutomation.stages = collectRepeatable(stagesSpec);
  content.aiAutomation.toolsLearning = $('#ai-tools').value.split(',').map(s => s.trim()).filter(Boolean);

  content.contact.email = $('#c-email').value;
  content.contact.phone = $('#c-phone').value;
  content.contact.location = $('#c-location').value;
  content.contact.whatsapp = $('#c-whatsapp').value;
  content.contact.linkedin = $('#c-linkedin').value;
  content.contact.github = $('#c-github').value;
  content.contact.formspreeEndpoint = $('#c-formspree').value;

  return content;
}

// ---------- Nav / login wiring ----------
function wirePanelNav() {
  $$('.admin-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $$('.admin-nav-btn').forEach(b => b.classList.remove('active'));
      $$('.admin-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      $('#' + btn.dataset.panel).classList.add('active');
    });
  });
}

async function connect() {
  state.owner = $('#repoOwner').value.trim();
  state.repo = $('#repoName').value.trim();
  state.branch = $('#repoBranch').value.trim() || 'main';
  state.token = $('#repoToken').value.trim();
  const status = $('#loginStatus');

  if (!state.owner || !state.repo || !state.token) {
    status.textContent = 'Fill in username, repository name, and token.';
    status.className = 'form-status error';
    return;
  }

  status.textContent = 'Connecting…';
  status.className = 'form-status';
  try {
    await loadContentFromRepo();
    sessionStorage.setItem('admin_token', state.token);
    if ($('#rememberDevice').checked) {
      localStorage.setItem('admin_owner', state.owner);
      localStorage.setItem('admin_repo', state.repo);
      localStorage.setItem('admin_branch', state.branch);
    }
    showEditor();
  } catch (err) {
    status.textContent = err.message;
    status.className = 'form-status error';
  }
}

function showEditor() {
  $('#loginScreen').style.display = 'none';
  $('#editorScreen').style.display = 'block';
  if (state.demoMode) {
    $('#adminConnStatus').textContent = '🎮 Demo mode — changes won\u2019t be saved';
    $('#logoutBtn').style.display = 'inline-flex';
    $('#logoutBtn').textContent = 'Exit demo';
    $('#saveBtn').textContent = '💾 Save (connect to enable)';
    $('#editorScreen').insertAdjacentHTML('afterbegin', '<div class="admin-demo-banner">🎮 You\u2019re in demo mode — browse every panel and try adding/editing freely. Nothing is written to GitHub until you connect with a real token from the login screen.</div>');
  } else {
    $('#logoutBtn').style.display = 'inline-flex';
    $('#logoutBtn').textContent = 'Log out';
    $('#adminConnStatus').textContent = `Connected — ${state.owner}/${state.repo} (${state.branch})`;
  }
  renderPanels(state.content);
}

async function tryDemo() {
  const status = $('#loginStatus');
  status.textContent = 'Loading demo…';
  status.className = 'form-status';
  try {
    state.content = await loadContentPublic();
    state.demoMode = true;
    showEditor();
  } catch (err) {
    status.textContent = err.message;
    status.className = 'form-status error';
  }
}

function logout() {
  sessionStorage.removeItem('admin_token');
  state.token = '';
  location.reload();
}

async function saveAll() {
  const status = $('#saveStatus');
  if (state.demoMode) {
    status.textContent = '🎮 This is demo mode — log out and connect with a real GitHub token to actually save.';
    status.className = 'form-status error';
    return;
  }
  status.textContent = 'Saving…';
  status.className = 'form-status';
  try {
    state.content = collectAllIntoContent();
    await saveContentToRepo();
    status.textContent = '✅ Saved. Your live site will update in a few seconds.';
    status.className = 'form-status success';
  } catch (err) {
    status.textContent = '❌ ' + err.message;
    status.className = 'form-status error';
  }
}

function init() {
  wirePanelNav();
  $('#connectBtn').addEventListener('click', connect);
  $('#demoBtn').addEventListener('click', tryDemo);
  $('#logoutBtn').addEventListener('click', logout);
  $('#saveBtn').addEventListener('click', saveAll);

  const savedOwner = localStorage.getItem('admin_owner');
  const savedRepo = localStorage.getItem('admin_repo');
  const savedBranch = localStorage.getItem('admin_branch');
  if (savedOwner) $('#repoOwner').value = savedOwner;
  if (savedRepo) $('#repoName').value = savedRepo;
  if (savedBranch) $('#repoBranch').value = savedBranch;

  const savedToken = sessionStorage.getItem('admin_token');
  if (savedOwner && savedRepo && savedToken) {
    state.owner = savedOwner; state.repo = savedRepo; state.branch = savedBranch || 'main'; state.token = savedToken;
    loadContentFromRepo().then(showEditor).catch(() => { /* fall back to login form silently */ });
  }
}

init();
