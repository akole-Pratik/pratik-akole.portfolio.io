// ==========================================================
// Pratik Akole — Portfolio v2 — public site renderer
// Reads /data/content.json and builds every section from it.
// Edit content.json (directly, or via admin.html) — never edit
// this file just to change text, add a project, etc.
// ==========================================================

const el = (sel, root = document) => root.querySelector(sel);
const els = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const create = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html !== undefined) n.innerHTML = html;
  return n;
};

async function loadContent() {
  const res = await fetch('data/content.json', { cache: 'no-store' });
  if (!res.ok) throw new Error('content.json not found');
  return res.json();
}

function renderHero(data) {
  const { hero } = data;
  el('#heroStatus').textContent = hero.status;
  el('#heroName').textContent = `Hi, I'm ${hero.shortName}`;
  el('#heroBio').textContent = hero.bio;
  const resumeBtns = [el('#heroResume'), el('#navResume')];
  if (hero.resumeUrl) {
    resumeBtns.forEach(b => { b.href = hero.resumeUrl; b.removeAttribute('aria-disabled'); });
  } else {
    resumeBtns.forEach(b => {
      b.href = '#';
      b.removeAttribute('download');
      b.setAttribute('aria-disabled', 'true');
      b.title = 'Resume coming soon';
      b.addEventListener('click', (e) => e.preventDefault());
    });
  }
  el('#heroLinkedin').href = hero.linkedin || '#';
  el('#heroGithub').href = hero.github || '#';
  el('#footerName').textContent = hero.name;

  // typing effect between two roles
  const typeTarget = el('#heroType');
  const words = [hero.taglineStart, hero.taglineEnd];
  let wi = 0, ci = 0, deleting = false;
  function tick() {
    const word = words[wi];
    if (!deleting) {
      ci++;
      typeTarget.textContent = word.slice(0, ci);
      if (ci === word.length) { deleting = true; setTimeout(tick, 1400); return; }
    } else {
      ci--;
      typeTarget.textContent = word.slice(0, ci);
      if (ci === 0) { deleting = false; wi = (wi + 1) % words.length; }
    }
    setTimeout(tick, deleting ? 45 : 75);
  }
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    typeTarget.textContent = words.join(' → ');
  } else {
    tick();
  }

  const statsWrap = el('#heroStats');
  hero.stats.forEach(s => {
    const d = create('div', 'stat', `<div class="value">${s.value}</div><div class="label">${s.label}</div>`);
    statsWrap.appendChild(d);
  });

  const kpiWrap = el('#heroKpis');
  hero.stats.forEach(s => {
    const d = create('div', 'data-kpi', `<div class="n">${s.value}</div><div class="l">${s.label}</div>`);
    kpiWrap.appendChild(d);
  });

  // interactive skill badges under the bio
  const badges = hero.badges || [];
  const badgeWrap = el('#heroBadges');
  badges.forEach(b => badgeWrap.appendChild(create('span', 'hero-badge', b)));

  // animated mini bar chart inside the insight panel (decorative, represents "data")
  const chartWrap = el('#miniChart');
  const heights = [55, 80, 40, 95, 65, 75];
  heights.forEach((h, i) => {
    const bar = create('div', 'bar');
    bar.style.height = h + '%';
    bar.style.animationDelay = (i * 0.08) + 's';
    chartWrap.appendChild(bar);
  });

  // floating skill badges around the visual panel
  const orbitWrap = el('#orbitBadges');
  const positions = [
    { top: '4%', left: '2%' }, { top: '18%', right: '4%' }, { top: '48%', left: '-4%' },
    { bottom: '20%', right: '-2%' }, { bottom: '2%', left: '12%' }, { top: '58%', right: '18%' },
  ];
  badges.slice(0, positions.length).forEach((b, i) => {
    const chip = create('span', 'orbit-badge', b);
    Object.assign(chip.style, positions[i], { animationDelay: (i * 0.6) + 's' });
    orbitWrap.appendChild(chip);
  });
}

function renderAbout(data) {
  el('#aboutSummary').textContent = data.about.summary;
  const qf = el('#quickFacts');
  data.about.quickFacts.forEach(f => {
    qf.appendChild(create('div', 'quick-fact', `<span class="icon">${f.icon}</span><div><div class="label">${f.label}</div><div class="value">${f.value}</div></div>`));
  });

  const expWrap = el('#aboutExperienceCards');
  data.experience.forEach(e => {
    expWrap.appendChild(create('div', 'mini-card', `<span class="icon">💼</span><h4>${e.company}</h4><p>${e.role} · ${e.period}</p>`));
  });

  const projWrap = el('#aboutProjectCards');
  data.projects.forEach(p => {
    projWrap.appendChild(create('div', 'mini-card', `<span class="icon">📊</span><h4>${p.title}</h4><p>${p.summary}</p><span class="tag">${(p.categories || []).join(' · ')}</span>`));
  });

  const techWrap = el('#aboutTechCards');
  data.skills.forEach(cat => {
    techWrap.appendChild(create('div', 'mini-card', `<span class="icon">${cat.icon}</span><h4>${cat.category}</h4><p>${cat.items.map(i => i.name).join(', ')}</p>`));
  });

  const certWrap = el('#aboutCertCards');
  [...data.certifications, ...data.achievements].forEach(c => {
    const dateStr = c.date ? ` · ${c.date}` : '';
    certWrap.appendChild(create('div', 'mini-card', `<span class="icon">${c.icon}</span><h4>${c.title}</h4><p>${c.desc || c.issuer || ''}${dateStr}</p>`));
  });

  // tabs behaviour
  els('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      els('.tab-btn').forEach(b => b.setAttribute('aria-selected', 'false'));
      els('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.setAttribute('aria-selected', 'true');
      el('#' + btn.dataset.tab).classList.add('active');
    });
  });
}

function renderExperience(data) {
  const wrap = el('#timeline');
  data.experience.forEach((e, i) => {
    const item = create('div', `timeline-item${e.current ? ' current' : ''}`);
    item.innerHTML = `
      <div class="timeline-dot"></div>
      <div class="timeline-card${i === 0 ? ' open' : ''}">
        <div class="timeline-top">
          <div>
            <h3>${e.company}${e.current ? '<span class="badge-current">Current</span>' : ''}</h3>
            <div class="timeline-role">${e.role}</div>
          </div>
          <div class="timeline-period">${e.period}</div>
        </div>
        <ul class="timeline-points">
          ${e.points.map(p => `<li>${p}</li>`).join('')}
        </ul>
        <span class="timeline-toggle">${i === 0 ? 'Hide details ↑' : 'Show details ↓'}</span>
      </div>`;
    const card = item.querySelector('.timeline-card');
    const toggle = item.querySelector('.timeline-toggle');
    card.addEventListener('click', () => {
      card.classList.toggle('open');
      toggle.textContent = card.classList.contains('open') ? 'Hide details ↑' : 'Show details ↓';
    });
    wrap.appendChild(item);
  });
}

function renderSkills(data) {
  const wrap = el('#skillsGrid');
  data.skills.forEach(cat => {
    const card = create('div', 'skill-card');
    card.innerHTML = `
      <div class="skill-card-head"><span class="icon">${cat.icon}</span><h3>${cat.category}</h3></div>
      ${cat.items.map(i => `<div class="skill-item"><span>${i.name}</span><span class="level-pill level-${i.level}">${i.level}</span></div>`).join('')}
    `;
    wrap.appendChild(card);
  });
}

let allProjects = [];
function renderProjects(data) {
  allProjects = data.projects;
  const categories = ['All', ...new Set(data.projects.flatMap(p => p.categories))];
  const filterBar = el('#filterBar');
  categories.forEach((cat, i) => {
    const btn = create('button', 'filter-chip', cat);
    btn.setAttribute('aria-pressed', i === 0 ? 'true' : 'false');
    btn.addEventListener('click', () => {
      els('.filter-chip').forEach(b => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
      drawProjects(cat);
    });
    filterBar.appendChild(btn);
  });
  drawProjects('All');
}

function drawProjects(filter) {
  const grid = el('#projectsGrid');
  grid.innerHTML = '';
  const list = filter === 'All' ? allProjects : allProjects.filter(p => p.categories.includes(filter));
  if (!list.length) {
    grid.appendChild(create('div', 'projects-empty', 'No projects in this category yet.'));
    return;
  }
  list.forEach(p => {
    const card = create('div', 'project-card');
    const thumb = p.dashboardImage
      ? `<img src="${p.dashboardImage}" alt="${p.title} preview">`
      : `<span>// no preview attached yet</span>`;
    card.innerHTML = `
      <div class="project-thumb">${thumb}</div>
      <div class="project-body">
        <div class="project-tags">${p.categories.map(c => `<span class="project-tag">${c}</span>`).join('')}</div>
        <h3>${p.title}</h3>
        <div class="project-toolline">${p.toolLine || ''}</div>
        <p class="project-summary">${p.summary}</p>
        <span class="project-open">View case study →</span>
      </div>`;
    card.addEventListener('click', () => openModal(p));
    grid.appendChild(card);
  });
}

function openModal(p) {
  el('#modalTitle').textContent = p.title;
  el('#modalToolLine').textContent = p.toolLine || (p.tools || []).join(' · ');
  const body = el('#modalBody');
  const thumb = p.dashboardImage ? `<div class="modal-thumb"><img src="${p.dashboardImage}" alt="${p.title} dashboard"></div>` : '';
  const kpis = (p.kpis && p.kpis.length) ? `<div class="modal-section"><h4>KPIs tracked</h4><ul>${p.kpis.map(k => `<li>${k}</li>`).join('')}</ul></div>` : '';
  const questions = (p.businessQuestions && p.businessQuestions.length) ? `<div class="modal-section"><h4>Business questions</h4><ul>${p.businessQuestions.map(q => `<li>${q}</li>`).join('')}</ul></div>` : '';
  const insights = (p.insights && p.insights.length) ? `<div class="modal-section"><h4>Key insights</h4><ul>${p.insights.map(i => `<li>${i}</li>`).join('')}</ul></div>` : '';
  const files = (p.files && p.files.length) ? `<div class="modal-section"><h4>Attached files</h4><div class="modal-files">${p.files.map(f => `<a class="file-chip" href="${f.url}" target="_blank" rel="noopener">📎 ${f.name}</a>`).join('')}</div></div>` : '';
  const actions = [];
  if (p.caseStudyLink) actions.push(`<a class="btn btn-outline" href="${p.caseStudyLink}" target="_blank" rel="noopener">View Case Study</a>`);
  if (p.dashboardLink) actions.push(`<a class="btn btn-primary" href="${p.dashboardLink}" target="_blank" rel="noopener">View Dashboard</a>`);

  body.innerHTML = `
    ${thumb}
    <div class="modal-flow">
      <div><span>Business Problem</span>${p.businessProblem || '—'}</div>
      <div><span>Dataset</span>${p.dataset || '—'}</div>
      <div><span>Approach</span>${p.approach || '—'}</div>
      <div><span>Tools</span>${(p.tools || []).join(', ') || '—'}</div>
    </div>
    ${questions}
    ${kpis}
    ${insights}
    <div class="modal-section"><h4>Business impact</h4><p>${p.impact || 'Add the measurable business impact.'}</p></div>
    ${files}
    ${actions.length ? `<div class="modal-actions">${actions.join('')}</div>` : ''}
  `;
  el('#modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  el('#modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

function renderAI(data) {
  el('#aiIntro').textContent = data.aiAutomation.intro;
  const wrap = el('#aiRoadmap');
  data.aiAutomation.stages.forEach((s, i) => {
    wrap.appendChild(create('div', 'roadmap-step', `<div class="num">${String(i + 1).padStart(2, '0')}</div><h4>${s.title}</h4><p>${s.desc}</p>`));
  });
  const toolsWrap = el('#aiTools');
  data.aiAutomation.toolsLearning.forEach(t => toolsWrap.appendChild(create('span', 'pill-dark', t)));
}

function renderContact(data) {
  const c = data.contact;
  el('#footerLocation').textContent = c.location;
  const wrap = el('#contactCards');
  const items = [
    { icon: '📧', label: 'Email', value: c.email, href: `mailto:${c.email}` },
    { icon: '📞', label: 'Phone', value: c.phone, href: `tel:${c.phone}` },
    { icon: '💼', label: 'LinkedIn', value: 'Connect with me', href: c.linkedin },
    { icon: '💻', label: 'GitHub', value: 'See my code', href: c.github },
    { icon: '📄', label: 'Resume', value: 'Download PDF', href: data.hero.resumeUrl },
  ];
  if (c.whatsapp) items.splice(2, 0, { icon: '💬', label: 'WhatsApp', value: 'Message me', href: `https://wa.me/${c.whatsapp.replace(/\D/g, '')}` });
  items.forEach(i => {
    if (!i.value) return;
    const a = create('a', 'contact-card', `<span class="icon">${i.icon}</span><div><div class="label">${i.label}</div><div class="value">${i.value}</div></div>`);
    a.href = i.href || '#';
    if (i.href && i.href.startsWith('http')) { a.target = '_blank'; a.rel = 'noopener'; }
    wrap.appendChild(a);
  });

  const form = el('#contactForm');
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const status = el('#formStatus');
    const endpoint = c.formspreeEndpoint;
    if (!endpoint || endpoint.includes('REPLACE_WITH_YOUR_FORM_ID')) {
      status.textContent = 'Form isn\u2019t connected yet — email me directly instead.';
      status.className = 'form-status error';
      return;
    }
    status.textContent = 'Sending…';
    status.className = 'form-status';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Accept': 'application/json' },
        body: new FormData(form),
      });
      if (res.ok) {
        status.textContent = 'Message sent — thanks! I\u2019ll get back to you soon.';
        status.className = 'form-status success';
        form.reset();
      } else {
        status.textContent = 'Something went wrong sending that. Try emailing me directly.';
        status.className = 'form-status error';
      }
    } catch (e) {
      status.textContent = 'Network error — try emailing me directly.';
      status.className = 'form-status error';
    }
  });
}

function wireNav() {
  const toggle = el('#navToggle');
  const links = el('#navLinks');
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
  els('#navLinks a').forEach(a => a.addEventListener('click', () => {
    links.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
  }));

  el('#modalClose').addEventListener('click', closeModal);
  el('#modalOverlay').addEventListener('click', (e) => { if (e.target.id === 'modalOverlay') closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
}

async function init() {
  el('#year').textContent = new Date().getFullYear();
  wireNav();
  try {
    const data = await loadContent();
    renderHero(data);
    renderAbout(data);
    renderExperience(data);
    renderSkills(data);
    renderProjects(data);
    renderAI(data);
    renderContact(data);
  } catch (err) {
    console.error(err);
    document.body.insertAdjacentHTML('afterbegin', '<p style="background:#d1485b;color:#fff;padding:12px;text-align:center;font-family:monospace;">Could not load content.json — check the file exists at /data/content.json</p>');
  }
}

init();
